#!/usr/bin/env python3
"""Example 2: General Relativity"""
from ust_physics import gr
from ust_physics.constants import M_SUN

bh = gr.Schwarzschild(mass=M_SUN)
print("Schwarzschild Black Hole (Solar Mass)")
print(f"Event Horizon: {bh.schwarzschild_radius()/1000:.2f} km")
print(f"Photon Sphere: {bh.photon_sphere()/1000:.2f} km")
print(f"ISCO: {bh.innermost_stable_orbit()/1000:.2f} km")

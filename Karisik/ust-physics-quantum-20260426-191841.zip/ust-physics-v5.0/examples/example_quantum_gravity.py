#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Quantum Gravity with UST Examples
Author: Niyazi ÖCAL, Patent: TR 2026/003258
"""

from ust_physics.quantum_gravity import (
    PlanckScaleUST, BlackHoleQuantum, LoopQuantumUST,
    GravitonUST, HolographyUST
)
from ust_physics.constants import M_SUN

print("\n" + "="*70)
print("QUANTUM GRAVITY + UST EXAMPLES")
print("="*70)

# 1. Planck Scale
print("\n[1] PLANCK SCALE")
print("-"*70)
planck = PlanckScaleUST()
planck.summary()

# 2. Black Hole
print("\n[2] BLACK HOLE QUANTUM EFFECTS")
print("-"*70)
bh = BlackHoleQuantum(mass=M_SUN)
bh.summary()

# 3. Loop Quantum Gravity
print("\n[3] LOOP QUANTUM GRAVITY")
print("-"*70)
lqg = LoopQuantumUST()
lqg.summary()

# 4. Graviton
print("\n[4] GRAVITON PROPERTIES")
print("-"*70)
graviton = GravitonUST()
graviton.summary()

# 5. Holography
print("\n[5] HOLOGRAPHIC PRINCIPLE")
print("-"*70)
holo = HolographyUST()
holo.summary()

# Summary Table
print("\n" + "="*70)
print("UST QUANTUM GRAVITY PREDICTIONS SUMMARY")
print("="*70)
print(f"{'Effect':<30} {'UST Formula':<25} {'Physical Meaning'}")
print("-"*70)
print(f"{'Planck Length':<30} {'l_P × N_b':<25} {'Active compression'}")
print(f"{'Hawking Temperature':<30} {'T_H × Cc_b':<25} {'63% cooler (T17)'}")
print(f"{'LQG Immirzi':<30} {'β = T_Om':<25} {'Natural parameter'}")
print(f"{'Graviton Mass Bound':<30} {'m_g × Cc_b':<25} {'Omnium constraint'}")
print(f"{'Holographic Entropy':<30} {'S × N_b':<25} {'Active fraction'}")
print(f"{'AdS/CFT':<30} {'17D → 16D':<25} {'Omnium holographic'}")
print("="*70)

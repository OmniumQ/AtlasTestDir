#!/usr/bin/env python3
"""Example 1: Basic UST"""
import ust_physics as ust
ust.constants.info()
print("\n")
ust.theorems.verify_all()

#!/usr/bin/env python3
"""Example 3: QFT"""
from ust_physics import qft

qed = qft.QED()
print(f"g-2 (electron, 1-loop): {qed.g2_anomaly(order=1):.10f}")
print(f"g-2 (electron, 2-loop): {qed.g2_anomaly(order=2):.10f}")
print(f"α(M_Z): {qft.running_alpha(91.2):.6f}")
print(f"α_s(M_Z): {qft.running_alpha_s(91.2):.4f}")

# -*- coding: utf-8 -*-
"""Test Quantum Gravity Module"""
import pytest
import numpy as np
from ust_physics.quantum_gravity import *
from ust_physics.constants import M_SUN, N_b, Cc_b, T_Om

def test_planck_scale():
    p = PlanckScaleUST()
    assert p.planck_length_ust() > 0
    assert p.planck_length_ust() < p.l_P_standard

def test_black_hole():
    bh = BlackHoleQuantum(mass=M_SUN)
    assert bh.hawking_temperature_ust() > 0
    info = bh.information_paradox_resolution()
    assert np.isclose(info['total_conserved'], 1.0)

def test_lqg():
    lqg = LoopQuantumUST()
    assert np.isclose(lqg.beta, T_Om, rtol=0.01)

def test_graviton():
    g = GravitonUST()
    assert g.graviton_mass_bound_ust() > 0

def test_holography():
    h = HolographyUST()
    dims = h.ads_cft_dimension_matching()
    assert dims['bulk_dimensions'] == 17

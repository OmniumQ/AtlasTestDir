# -*- coding: utf-8 -*-
"""
Black Hole Quantum Effects with UST
Author: Niyazi ÖCAL, Patent: TR 2026/003258
"""

import numpy as np
from ..constants import G, HBAR, C, K_B, N_b, Cc_b, T_Om, PI

class BlackHoleQuantum:
    """Quantum black hole thermodynamics with UST corrections"""
    
    def __init__(self, mass):
        self.mass = mass
        self.r_s = 2 * G * mass / C**2
        
    def hawking_temperature_ust(self):
        """T_H^UST = (ℏc³)/(8πGMk_B) × Cc_b (63% cooler)"""
        T_H_standard = HBAR * C**3 / (8 * PI * G * self.mass * K_B)
        return T_H_standard * Cc_b
    
    def bekenstein_hawking_entropy_ust(self):
        """S_BH^UST = (A × k_B)/(4 × l_P²) × N_b"""
        A = 4 * PI * self.r_s**2
        l_P = np.sqrt(HBAR * G / C**3)
        S_BH_standard = (A * K_B) / (4 * l_P**2)
        return S_BH_standard * N_b
    
    def information_paradox_resolution(self):
        """Information split: N_b preserved, Cc_b to Omnium"""
        return {
            'preserved_fraction': N_b,
            'omnium_fraction': Cc_b,
            'total_conserved': N_b + Cc_b,
            'tunnel_rate': T_Om,
            'reversible': True
        }
    
    def hawking_radiation_spectrum_ust(self, frequency):
        """dN/dω with UST modification"""
        T_H = self.hawking_temperature_ust()
        omega = 2 * PI * frequency
        Gamma_ust = 1.0 * N_b
        
        if HBAR * omega / (K_B * T_H) > 100:
            return 0
        
        return (Gamma_ust / (2 * PI)) / (np.exp(HBAR * omega / (K_B * T_H)) - 1)
    
    def omnium_horizon(self):
        """r_Om = r_s / N_b (T17)"""
        return self.r_s / N_b
    
    def evaporation_time_ust(self):
        """t_evap^UST = standard × (1/Cc_b) - slower evaporation"""
        t_evap_standard = (5120 * PI * G**2 * self.mass**3) / (HBAR * C**4)
        return t_evap_standard / Cc_b
    
    def summary(self):
        print("="*70)
        print("BLACK HOLE QUANTUM PROPERTIES (UST)")
        print("="*70)
        print(f"Mass:                     {self.mass:.3e} kg")
        print(f"Schwarzschild Radius:     {self.r_s/1000:.2f} km")
        print(f"Omnium Horizon:           {self.omnium_horizon()/1000:.2f} km")
        print(f"Hawking Temperature:      {self.hawking_temperature_ust():.3e} K")
        print(f"BH Entropy (UST):         {self.bekenstein_hawking_entropy_ust():.3e}")
        print(f"Evaporation Time:         {self.evaporation_time_ust():.3e} s")
        info = self.information_paradox_resolution()
        print(f"Info Preserved:           {info['preserved_fraction']:.6f}")
        print(f"Info in Omnium:           {info['omnium_fraction']:.6f}")
        print("="*70)

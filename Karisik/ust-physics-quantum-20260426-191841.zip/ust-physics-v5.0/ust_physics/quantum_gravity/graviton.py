# -*- coding: utf-8 -*-
"""
Graviton Properties with UST
Author: Niyazi ÖCAL, Patent: TR 2026/003258
"""

import numpy as np
from ..constants import HBAR, C, G, N_b, Cc_b, T_Om, H0_PLANCK

class GravitonUST:
    """Graviton particle properties modified by UST"""
    
    def __init__(self):
        self.spin = 2
        
    def graviton_mass_bound_ust(self):
        """m_g < (ℏ/c²) × H_0 × Cc_b"""
        H0_si = H0_PLANCK * 1000 / (3.086e22)
        m_g_bound = (HBAR * H0_si / C**2) * Cc_b
        return m_g_bound
    
    def graviton_omnium_coupling(self):
        """g_Om = √(8πG/ℏc) × T_Om"""
        g_Om = np.sqrt(8 * np.pi * G / (HBAR * C)) * T_Om
        return g_Om
    
    def virtual_graviton_propagator_ust(self, momentum_squared):
        """D(q²) = (1/q²) × N_b"""
        if momentum_squared == 0:
            return np.inf
        return N_b / momentum_squared
    
    def gravitational_wave_speed_ust(self):
        """v_GW = c × (1 - T_Om²/2)"""
        return C * (1 - T_Om**2 / 2)
    
    def graviton_decay_to_omnium(self, omega):
        """Γ_Om = (ω³/(ℏc³)) × T_Om² × Cc_b"""
        return (omega**3 / (HBAR * C**3)) * T_Om**2 * Cc_b
    
    def summary(self):
        print("="*70)
        print("GRAVITON PROPERTIES (UST)")
        print("="*70)
        print(f"Spin:                     {self.spin}")
        print(f"Mass Bound (UST):         {self.graviton_mass_bound_ust():.3e} kg")
        print(f"Omnium Coupling:          {self.graviton_omnium_coupling():.6e}")
        print(f"GW Speed (UST):           {self.gravitational_wave_speed_ust():.10e} m/s")
        print(f"GW Speed / c:             {self.gravitational_wave_speed_ust()/C:.15f}")
        delta_v = (1 - self.gravitational_wave_speed_ust()/C) * 1e6
        print(f"Speed Reduction:          {delta_v:.2f} ppm")
        print("="*70)

# -*- coding: utf-8 -*-
"""
Planck Scale with UST Corrections
Author: Niyazi ÖCAL, Patent: TR 2026/003258
"""

import numpy as np
from ..constants import G, HBAR, C, N_b, Cc_b, T_Om, K_B

class PlanckScaleUST:
    """Planck units modified by UST"""
    
    def __init__(self):
        self.l_P_standard = np.sqrt(HBAR * G / C**3)
        self.m_P_standard = np.sqrt(HBAR * C / G)
        self.t_P_standard = np.sqrt(HBAR * G / C**5)
        self.E_P_standard = np.sqrt(HBAR * C**5 / G)
        
    def planck_length_ust(self):
        """Formula: l_P^UST = l_P × N_b"""
        return self.l_P_standard * N_b
    
    def planck_mass_ust(self):
        """Formula: m_P^UST = m_P / N_b"""
        return self.m_P_standard / N_b
    
    def planck_time_ust(self):
        """Formula: t_P^UST = t_P × Cc_b"""
        return self.t_P_standard * Cc_b
    
    def planck_energy_ust(self):
        """Formula: E_P^UST = E_P × (1 + T_Om)"""
        return self.E_P_standard * (1 + T_Om)
    
    def planck_temperature_ust(self):
        """Formula: T_P^UST = T_P / Cc_b"""
        T_P_standard = self.E_P_standard / K_B
        return T_P_standard / Cc_b
    
    def quantum_gravity_scale(self):
        """Energy scale where QG becomes important (in GeV)"""
        E_QG = self.planck_energy_ust() * N_b * Cc_b
        eV_to_J = 1.602176634e-19
        return E_QG / (1e9 * eV_to_J)
    
    def summary(self):
        print("="*70)
        print("PLANCK SCALE WITH UST CORRECTIONS")
        print("="*70)
        print(f"Planck Length (UST):      {self.planck_length_ust():.3e} m")
        print(f"Planck Mass (UST):        {self.planck_mass_ust():.3e} kg")
        print(f"Planck Time (UST):        {self.planck_time_ust():.3e} s")
        print(f"Planck Energy (UST):      {self.planck_energy_ust():.3e} J")
        print(f"Planck Temperature (UST): {self.planck_temperature_ust():.3e} K")
        print(f"QG Energy Scale:          {self.quantum_gravity_scale():.3e} GeV")
        print("="*70)

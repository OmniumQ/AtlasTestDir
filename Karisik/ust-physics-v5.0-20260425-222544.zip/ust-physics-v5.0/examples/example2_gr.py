#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Example 2: General Relativity
Beispiel 2: Allgemeine Relativitätstheorie
Örnek 2: Genel Görelilik
"""

from ust_physics import gr
from ust_physics.constants import M_SUN

# Create Schwarzschild black hole | Schwarzschild Schwarzes Loch erstellen
# Schwarzschild kara deliği oluştur
bh = gr.Schwarzschild(mass=M_SUN)

print("="*60)
print("Schwarzschild Black Hole (Solar Mass)")
print("="*60)
print(f"Schwarzschild radius: {bh.schwarzschild_radius()/1000:.2f} km")
print(f"Photon sphere:        {bh.photon_sphere()/1000:.2f} km")
print(f"ISCO:                 {bh.innermost_stable_orbit()/1000:.2f} km")
print("="*60)

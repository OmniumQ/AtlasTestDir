#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Example 1: Basic UST Usage
Beispiel 1: Grundlegende UST-Verwendung
Örnek 1: Temel UST Kullanımı
"""

import ust_physics as ust

# Display constants | Konstanten anzeigen | Sabitleri göster
print("\nUST Constants:")
ust.constants.info()

# Verify theorems | Theoreme überprüfen | Teoremleri doğrula
print("\n\nTheorem Verification:")
rms = ust.theorems.verify_all()

print(f"\n\nOverall RMS Error: {rms:.4f}%")

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Example 3: Quantum Field Theory
Beispiel 3: Quantenfeldtheorie
Örnek 3: Kuantum Alan Teorisi
"""

from ust_physics import qft

# QED calculations | QED-Berechnungen | QED hesaplamaları
qed = qft.QED()

print("="*60)
print("QED Calculations")
print("="*60)

g2_1loop = qed.g2_anomaly(particle='electron', order=1)
g2_2loop = qed.g2_anomaly(particle='electron', order=2)

print(f"g-2 (1-loop):  {g2_1loop:.10f}")
print(f"g-2 (2-loop):  {g2_2loop:.10f}")

# Running coupling | Laufende Kopplung | Koşan bağlaşım
alpha_91 = qft.running_alpha(energy_gev=91.2)
print(f"\nα(M_Z):        {alpha_91:.6f}")

alpha_s_91 = qft.running_alpha_s(energy_gev=91.2)
print(f"α_s(M_Z):      {alpha_s_91:.4f}")
print("="*60)

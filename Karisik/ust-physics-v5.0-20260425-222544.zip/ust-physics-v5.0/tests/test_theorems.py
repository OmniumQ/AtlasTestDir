# -*- coding: utf-8 -*-
"""
Test Theorems Module
Teste Theoreme-Modul
Teoremler Modülünü Test Et
"""

import pytest
import numpy as np
from ust_physics import theorems

def test_T5_dark_energy():
    """Test T5 theorem | Teste T5-Theorem | T5 teoremini test et"""
    pred, obs, delta = theorems.T5_dark_energy()
    assert delta < 10  # Less than 10% error

def test_T10_tunnel():
    """Test T10 theorem | Teste T10-Theorem | T10 teoremini test et"""
    t_om = theorems.T10_tunnel()
    assert 0.2 < t_om < 0.3

def test_T23_hubble():
    """Test T23 theorem | Teste T23-Theorem | T23 teoremini test et"""
    pred, obs, delta = theorems.T23_hubble_tension()
    assert delta < 15  # Less than 15% error

# -*- coding: utf-8 -*-
"""
Test Constants Module
Teste Konstantenmodul
Sabitler Modülünü Test Et
"""

import pytest
import numpy as np
from ust_physics.constants import N_b, Cc_b, T_Om, ALPHA

def test_blueprint_constant():
    """Test N_b value | Teste N_b-Wert | N_b değerini test et"""
    assert 0 < N_b < 1
    assert np.isclose(N_b, 0.63354460, rtol=1e-6)

def test_channel_c():
    """Test Cc_b value | Teste Cc_b-Wert | Cc_b değerini test et"""
    assert np.isclose(Cc_b, 1 - N_b, rtol=1e-10)

def test_tunnel_constant():
    """Test T_Om value | Teste T_Om-Wert | T_Om değerini test et"""
    expected = np.exp(-2 * np.pi * N_b * Cc_b)
    assert np.isclose(T_Om, expected, rtol=1e-6)

def test_alpha():
    """Test fine structure constant | Teste Feinstrukturkonstante | İnce yapı sabitini test et"""
    assert np.isclose(ALPHA, 1/137, rtol=0.01)

# -*- coding: utf-8 -*-
"""
Quantum Electrodynamics (QED)
Quantenelektrodynamik (QED)
Kuantum Elektrodinamiği (QED)

Author | Autor | Yazar: Niyazi ÖCAL
"""

import numpy as np
from ..constants import ALPHA, PI, M_E, E_CHARGE, HBAR, C

class QED:
    """
    QED calculations
    QED-Berechnungen
    QED hesaplamaları
    """
    
    def __init__(self):
        """Initialize QED | Initialisiere QED | QED'i başlat"""
        self.alpha = ALPHA
        
    def g2_anomaly(self, particle='electron', order=1):
        """
        Calculate anomalous magnetic moment g-2
        Berechne anomales magnetisches Moment g-2
        Anomali manyetik moment g-2 hesapla
        
        Formula | Formel | Formül:
            a = (g-2)/2 = α/(2π) + ...
            
        Args | Argumente | Parametreler:
            particle: 'electron' or 'muon'
            order: Perturbation order (1, 2, 3)
            
        Returns | Rückgabe | Döndürür:
            a_e or a_μ value
        """
        # 1-loop (Schwinger term)
        a_1loop = self.alpha / (2 * PI)
        
        if order == 1:
            return a_1loop
        
        # 2-loop
        a_2loop = 0.328478965 * (self.alpha / PI)**2
        
        if order == 2:
            return a_1loop + a_2loop
        
        # 3-loop (approximate)
        a_3loop = 1.181234 * (self.alpha / PI)**3
        
        return a_1loop + a_2loop + a_3loop
    
    def lamb_shift(self, n=2):
        """
        Calculate Lamb shift
        Berechne Lamb-Verschiebung
        Lamb kaymasını hesapla
        
        Args | Argumente | Parametreler:
            n: Principal quantum number
            
        Returns | Rückgabe | Döndürür:
            Lamb shift in eV
        """
        # Simplified Lamb shift for hydrogen
        # Vereinfachte Lamb-Verschiebung für Wasserstoff
        # Hidrojen için basitleştirilmiş Lamb kayması
        rydberg = 13.6  # eV
        lamb = (self.alpha**5 / PI) * rydberg / n**3
        return lamb
    
    def fine_structure_constant(self):
        """
        Return fine structure constant
        Rückgabe Feinstrukturkonstante
        İnce yapı sabitini döndür
        
        Returns | Rückgabe | Döndürür:
            α ≈ 1/137
        """
        return self.alpha
    
    def compton_wavelength(self, particle='electron'):
        """
        Calculate Compton wavelength
        Berechne Compton-Wellenlänge
        Compton dalga boyunu hesapla
        
        Formula | Formel | Formül:
            λ_C = h/(m·c)
            
        Args | Argumente | Parametreler:
            particle: 'electron', 'proton', etc.
            
        Returns | Rückgabe | Döndürür:
            λ_C in meters
        """
        from ..constants import H_PLANCK
        
        if particle == 'electron':
            mass = M_E
        else:
            mass = M_E  # Default
            
        return H_PLANCK / (mass * C)

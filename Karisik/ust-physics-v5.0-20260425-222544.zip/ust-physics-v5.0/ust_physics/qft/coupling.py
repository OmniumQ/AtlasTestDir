# -*- coding: utf-8 -*-
"""
Running Coupling Constants
Laufende Kopplungskonstanten
Koşan Bağlaşım Sabitleri

Author | Autor | Yazar: Niyazi ÖCAL
"""

import numpy as np
from ..constants import ALPHA, ALPHA_S, PI

def running_alpha(energy_gev, n_flavors=1):
    """
    Calculate running fine structure constant α(E)
    Berechne laufende Feinstrukturkonstante α(E)
    Koşan ince yapı sabitini hesapla α(E)
    
    Formula | Formel | Formül:
        α(E) = α / (1 - (α/(3π))·ln(E/m_e)·n_f)
        
    Args | Argumente | Parametreler:
        energy_gev: Energy scale in GeV
        n_flavors: Number of active flavors
        
    Returns | Rückgabe | Döndürür:
        α(E) at energy scale
    """
    m_e_gev = 0.511e-3  # Electron mass in GeV
    
    if energy_gev <= m_e_gev:
        return ALPHA
    
    beta0 = (4/3) * n_flavors
    t = np.log(energy_gev / m_e_gev)
    
    alpha_E = ALPHA / (1 - (ALPHA / (3 * PI)) * beta0 * t)
    
    return alpha_E

def running_alpha_s(energy_gev, n_flavors=5):
    """
    Calculate running strong coupling α_s(E)
    Berechne laufende starke Kopplung α_s(E)
    Koşan güçlü bağlaşımı hesapla α_s(E)
    
    Formula | Formel | Formül:
        α_s(E) = α_s(M_Z) / (1 + β₀·α_s·ln(E/M_Z)/(2π))
        
    Args | Argumente | Parametreler:
        energy_gev: Energy scale in GeV
        n_flavors: Number of active quark flavors
        
    Returns | Rückgabe | Döndürür:
        α_s(E) at energy scale
    """
    M_Z = 91.2  # Z-boson mass in GeV
    
    if energy_gev <= 1.0:
        return ALPHA_S
    
    # β₀ = (11 - 2n_f/3) for QCD
    beta0 = 11 - (2 * n_flavors / 3)
    t = np.log(energy_gev / M_Z)
    
    alpha_s_E = ALPHA_S / (1 + beta0 * ALPHA_S * t / (2 * PI))
    
    return alpha_s_E

# -*- coding: utf-8 -*-
"""
Friedmann Equations
Friedmann-Gleichungen
Friedmann Denklemleri

Author | Autor | Yazar: Niyazi ÖCAL
"""

import numpy as np
from ..constants import G, C, H0_PLANCK, OMEGA_LAMBDA, OMEGA_DM, OMEGA_B

class Friedmann:
    """
    Friedmann equations for cosmology
    Friedmann-Gleichungen für Kosmologie
    Kozmoloji için Friedmann denklemleri
    
    Equations | Gleichungen | Denklemler:
        H² = (8πG/3)ρ - k/a²
        ä/a = -(4πG/3)(ρ + 3p)
    """
    
    def __init__(self, omega_lambda=OMEGA_LAMBDA, omega_dm=OMEGA_DM, omega_b=OMEGA_B):
        """
        Initialize Friedmann model
        Initialisiere Friedmann-Modell
        Friedmann modelini başlat
        
        Args | Argumente | Parametreler:
            omega_lambda: Dark energy density | Dunkle-Energie-Dichte | Karanlık enerji yoğunluğu
            omega_dm: Dark matter density | Dunkle-Materie-Dichte | Karanlık madde yoğunluğu
            omega_b: Baryon density | Baryonendichte | Baryon yoğunluğu
        """
        self.omega_lambda = omega_lambda
        self.omega_dm = omega_dm
        self.omega_b = omega_b
        self.omega_total = omega_lambda + omega_dm + omega_b
        
    def hubble_parameter(self, a):
        """
        Calculate Hubble parameter H(a)
        Berechne Hubble-Parameter H(a)
        Hubble parametresi H(a) hesapla
        
        Args | Argumente | Parametreler:
            a: Scale factor | Skalenfaktor | Ölçek faktörü
            
        Returns | Rückgabe | Döndürür:
            H(a) in km/s/Mpc
        """
        H0 = H0_PLANCK
        E = np.sqrt(
            self.omega_lambda 
            + self.omega_dm / a**3 
            + self.omega_b / a**3
        )
        return H0 * E
    
    def critical_density(self):
        """
        Calculate critical density
        Berechne kritische Dichte
        Kritik yoğunluğu hesapla
        
        Returns | Rückgabe | Döndürür:
            ρ_crit in kg/m³
        """
        H0_si = H0_PLANCK * 1000 / (3.086e22)  # Convert to 1/s
        return 3 * H0_si**2 / (8 * np.pi * G)
    
    def age_of_universe(self):
        """
        Calculate age of universe
        Berechne Alter des Universums
        Evrenin yaşını hesapla
        
        Returns | Rückgabe | Döndürür:
            Age in years | Alter in Jahren | Yaş yıl cinsinden
        """
        # Simplified calculation | Vereinfachte Berechnung | Basitleştirilmiş hesaplama
        H0_si = H0_PLANCK * 1000 / (3.086e22)
        t_H = 1 / H0_si  # Hubble time | Hubble-Zeit | Hubble zamanı
        t_years = t_H / (365.25 * 24 * 3600)
        return t_years * 0.965  # Correction factor | Korrekturfaktor | Düzeltme faktörü

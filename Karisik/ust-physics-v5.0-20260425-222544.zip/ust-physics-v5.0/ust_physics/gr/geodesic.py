# -*- coding: utf-8 -*-
"""
Geodesic Calculator
Geodätenrechner
Jeodezik Hesaplayıcı

Author | Autor | Yazar: Niyazi ÖCAL
"""

import numpy as np
from scipy.integrate import solve_ivp

class Geodesic:
    """
    Geodesic equation solver
    Geodätengleichungslöser
    Jeodezik denklem çözücü
    
    Equation | Gleichung | Denklem:
        d²x^μ/dλ² + Γ^μ_αβ (dx^α/dλ)(dx^β/dλ) = 0
    """
    
    def __init__(self, metric):
        """
        Initialize geodesic solver
        Initialisiere Geodätenlöser
        Jeodezik çözücüyü başlat
        
        Args | Argumente | Parametreler:
            metric: Metric object (e.g., Schwarzschild)
        """
        self.metric = metric
        
    def christoffel_symbols(self, r):
        """
        Calculate Christoffel symbols Γ^μ_αβ
        Berechne Christoffel-Symbole Γ^μ_αβ
        Christoffel sembollerini hesapla Γ^μ_αβ
        
        Args | Argumente | Parametreler:
            r: Radial coordinate | Radialkoordinate | Radyal koordinat
            
        Returns | Rückgabe | Döndürür:
            Dictionary of non-zero components
        """
        rs = self.metric.r_s
        
        # Non-zero Christoffel symbols for Schwarzschild
        # Nicht-null Christoffel-Symbole für Schwarzschild
        # Schwarzschild için sıfır-olmayan Christoffel sembolleri
        gamma = {}
        gamma['t_tr'] = rs / (2 * r * (r - rs))
        gamma['r_tt'] = rs * (r - rs) / (2 * r**3)
        gamma['r_rr'] = -rs / (2 * r * (r - rs))
        gamma['r_theta_theta'] = -(r - rs)
        gamma['r_phi_phi'] = -(r - rs) * np.sin(np.pi/2)**2
        gamma['theta_r_theta'] = 1 / r
        gamma['phi_r_phi'] = 1 / r
        
        return gamma
    
    def integrate(self, initial_conditions, t_span, n_points=1000):
        """
        Integrate geodesic equations
        Integriere Geodätengleichungen
        Jeodezik denklemleri entegre et
        
        Args | Argumente | Parametreler:
            initial_conditions: [t, r, θ, φ, dt/dλ, dr/dλ, dθ/dλ, dφ/dλ]
            t_span: (t_start, t_end) tuple
            n_points: Number of evaluation points
            
        Returns | Rückgabe | Döndürür:
            Solution object from solve_ivp
        """
        def geodesic_equations(lam, y):
            """Geodesic ODE system | Geodäten-ODE-System | Jeodezik ODE sistemi"""
            t, r, theta, phi, dt, dr, dtheta, dphi = y
            
            gamma = self.christoffel_symbols(r)
            
            # Second derivatives | Zweite Ableitungen | İkinci türevler
            ddt = -2 * gamma['t_tr'] * dt * dr
            ddr = gamma['r_tt'] * dt**2 + gamma['r_rr'] * dr**2
            ddtheta = -2 * gamma['theta_r_theta'] * dr * dtheta
            ddphi = -2 * gamma['phi_r_phi'] * dr * dphi
            
            return [dt, dr, dtheta, dphi, ddt, ddr, ddtheta, ddphi]
        
        sol = solve_ivp(
            geodesic_equations,
            t_span,
            initial_conditions,
            dense_output=True,
            max_step=0.1
        )
        
        return sol

# -*- coding: utf-8 -*-
"""
Schwarzschild Solution
Schwarzschild-Lösung
Schwarzschild Çözümü

Author | Autor | Yazar: Niyazi ÖCAL
"""

import numpy as np
from ..constants import G, C

class Schwarzschild:
    """
    Schwarzschild metric for non-rotating black holes
    Schwarzschild-Metrik für nicht rotierende schwarze Löcher
    Dönmeyen kara delikler için Schwarzschild metriği
    
    Metric | Metrik:
        ds² = -(1 - r_s/r) c²dt² + dr²/(1 - r_s/r) + r²dΩ²
        
    where | wobei | burada:
        r_s = 2GM/c² (Schwarzschild radius)
    """
    
    def __init__(self, mass):
        """
        Initialize Schwarzschild metric
        Initialisiere Schwarzschild-Metrik
        Schwarzschild metriğini başlat
        
        Args | Argumente | Parametreler:
            mass: Black hole mass in kg | Schwarzes-Loch-Masse in kg | Kara delik kütlesi kg
        """
        self.mass = mass
        self.r_s = 2 * G * mass / C**2
        
    def schwarzschild_radius(self):
        """
        Calculate Schwarzschild radius
        Berechne Schwarzschild-Radius
        Schwarzschild yarıçapını hesapla
        
        Returns | Rückgabe | Döndürür:
            r_s in meters | r_s in Metern | r_s metre cinsinden
        """
        return self.r_s
    
    def metric_tensor(self, r, theta=np.pi/2):
        """
        Calculate metric tensor g_μν
        Berechne Metriktensor g_μν
        Metrik tensörü g_μν hesapla
        
        Args | Argumente | Parametreler:
            r: Radial coordinate | Radialkoordinate | Radyal koordinat
            theta: Polar angle | Polarwinkel | Kutupsal açı
            
        Returns | Rückgabe | Döndürür:
            4×4 metric tensor | 4×4 Metriktensor | 4×4 metrik tensörü
        """
        g = np.zeros((4, 4))
        g[0, 0] = -(1 - self.r_s / r)
        g[1, 1] = 1 / (1 - self.r_s / r)
        g[2, 2] = r**2
        g[3, 3] = r**2 * np.sin(theta)**2
        return g
    
    def photon_sphere(self):
        """
        Calculate photon sphere radius
        Berechne Photonensphärenradius
        Foton küre yarıçapını hesapla
        
        Returns | Rückgabe | Döndürür:
            r_ph = 3M/2 in meters
        """
        return 1.5 * self.r_s
    
    def innermost_stable_orbit(self):
        """
        Calculate ISCO (innermost stable circular orbit)
        Berechne ISCO (innerste stabile Kreisbahn)
        ISCO'yu hesapla (en içteki kararlı dairesel yörünge)
        
        Returns | Rückgabe | Döndürür:
            r_ISCO = 6M in meters
        """
        return 3 * self.r_s

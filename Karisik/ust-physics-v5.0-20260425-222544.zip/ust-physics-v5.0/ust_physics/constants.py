# -*- coding: utf-8 -*-
"""
UST-Physics Constants Module
Physical constants for GR, QFT, and UST

Physikalische Konstanten für GR, QFT und UST
GR, QFT ve UST için fiziksel sabitler

Author | Autor | Yazar: Niyazi ÖCAL
Patent: TR 2026/003258
"""

import numpy as np

# =============================================================================
# FUNDAMENTAL PHYSICAL CONSTANTS
# GRUNDLEGENDE PHYSIKALISCHE KONSTANTEN
# TEMEL FİZİKSEL SABİTLER
# =============================================================================

# Mathematical constants | Mathematische Konstanten | Matematiksel sabitler
PI = np.pi
E = np.e
PHI = (1 + np.sqrt(5)) / 2  # Golden ratio | Goldener Schnitt | Altın oran

# Speed of light | Lichtgeschwindigkeit | Işık hızı
C = 2.99792458e8  # m/s

# Gravitational constant | Gravitationskonstante | Kütleçekim sabiti  
G = 6.67430e-11  # m³/(kg·s²)

# Planck constant | Planck-Konstante | Planck sabiti
H_PLANCK = 6.62607015e-34  # J·s
HBAR = H_PLANCK / (2 * PI)  # ℏ

# Boltzmann constant | Boltzmann-Konstante | Boltzmann sabiti
K_B = 1.380649e-23  # J/K

# Elementary charge | Elementarladung | Temel yük
E_CHARGE = 1.602176634e-19  # C

# Electron mass | Elektronenmasse | Elektron kütlesi
M_E = 9.1093837015e-31  # kg

# Proton mass | Protonenmasse | Proton kütlesi
M_P = 1.67262192369e-27  # kg

# Neutron mass | Neutronenmasse | Nötron kütlesi
M_N = 1.67492749804e-27  # kg

# Fine structure constant | Feinstrukturkonstante | İnce yapı sabiti
ALPHA = 7.2973525693e-3  # α ≈ 1/137

# Weak mixing angle | Schwacher Mischungswinkel | Zayıf karışım açısı
SIN2_THETA_W = 0.23121  # sin²θ_W

# Strong coupling | Starke Kopplung | Güçlü bağlaşım
ALPHA_S = 0.1179  # α_s(M_Z)

# =============================================================================
# COSMOLOGICAL CONSTANTS
# KOSMOLOGISCHE KONSTANTEN
# KOZMOLOJİK SABİTLER
# =============================================================================

# Hubble constants | Hubble-Konstanten | Hubble sabitleri
H0_PLANCK = 67.4  # km/s/Mpc (Planck 2018)
H0_LOCAL = 73.0  # km/s/Mpc (SH0ES)

# Density parameters | Dichteparameter | Yoğunluk parametreleri
OMEGA_LAMBDA = 0.6857  # Dark energy | Dunkle Energie | Karanlık enerji
OMEGA_DM = 0.2717  # Dark matter | Dunkle Materie | Karanlık madde
OMEGA_B = 0.0486  # Baryonic matter | Baryonische Materie | Baryonik madde

# Cosmological constant | Kosmologische Konstante | Kozmolojik sabit
LAMBDA_OBS = 1.100e-52  # m⁻²

# CMB temperature | CMB-Temperatur | CMB sıcaklığı
T_CMB = 2.72548  # K

# =============================================================================
# UST BLUEPRINT-MANIFEST CONSTANTS
# UST BLUEPRINT-MANIFEST KONSTANTEN
# UST BLUEPRINT-MANIFEST SABİTLERİ
# =============================================================================

# Geometric root | Geometrische Wurzel | Geometrik kök
N_GEO = (3 - np.sqrt(3)) / 2  # 0.63397460

# Blueprint constant | Blueprint-Konstante | Blueprint sabiti
N_b = N_GEO - ALPHA / 17  # 0.63354460

# Manifest constant | Manifest-Konstante | Manifest sabiti
N_m = 0.63353522  # Empirical | Empirisch | Ampirik

# Channel C (Blueprint) | Kanal C (Blueprint) | Kanal C (Blueprint)
Cc_b = 1.0 - N_b  # 0.36645540

# Channel C (Manifest) | Kanal C (Manifest) | Kanal C (Manifest)
Cc_m = 1.0 - N_m  # 0.36646478

# Transition gap | Übergangslücke | Geçiş boşluğu
RA = N_b - N_m  # 9.38e-6

# =============================================================================
# UST DERIVED CONSTANTS
# UST ABGELEITETE KONSTANTEN  
# UST TÜRETİLMİŞ SABİTLER
# =============================================================================

# Omnium tunnel constant | Omnium-Tunnelkonstante | Omnium tünel sabiti
T_Om = np.exp(-2 * PI * N_b * Cc_b)  # 0.23252885

# Blueprint-Manifest product | Blueprint-Manifest-Produkt | Blueprint-Manifest çarpımı
BPL = N_b * N_m  # 0.40145

# Gear constants | Getriebe-Konstanten | Vites sabitleri
KAPPA1 = PI * N_b  # Gear 1 | Getriebe 1 | Vites 1
KAPPA2 = 2 * PI * N_b  # Gear 2 | Getriebe 2 | Vites 2
V_b = (1 + N_b) / (2 - N_b)  # Gear transition | Getriebe-Übergang | Vites geçişi

# Metric components | Metrische Komponenten | Metrik bileşenleri
G_TT = -(1 - N_b) * (2 - N_b)  # g_tt
G_RR = 1.0 / ((1 - N_b) * (2 - N_b))  # g_rr

# =============================================================================
# UST COSMOLOGICAL PREDICTIONS
# UST KOSMOLOGISCHE VORHERSAGEN
# UST KOZMOLOJİK TAHMİNLER
# =============================================================================

# Dark energy prediction | Dunkle-Energie-Vorhersage | Karanlık enerji tahmini
OMEGA_LAMBDA_UST = N_b + OMEGA_DM / (PHI * PI)

# Cosmological constant prediction | Kosmologische-Konstante-Vorhersage | Kozmolojik sabit tahmini
L_PLANCK = 1.616e-35  # Planck length | Planck-Länge | Planck uzunluğu
LAMBDA_PLANCK = 1.0 / L_PLANCK**2
LAMBDA_UST = LAMBDA_PLANCK * (N_b**2)**(2 / (1 + ALPHA))

# Hubble tension prediction | Hubble-Spannungsvorhersage | Hubble gerilimi tahmini
H0_RATIO_UST = 1 + N_b * Cc_b**2  # 1.085078

# =============================================================================
# CYCLIC UNIVERSE CONSTANTS
# ZYKLISCHE UNIVERSUMSKONSTANTEN
# DÖNGÜSEL EVREN SABİTLERİ
# =============================================================================

# Cycle count | Zyklusanzahl | Döngü sayısı
CYCLE_COUNT = 1.0 / T_Om  # 4.3005

# Next universe constants | Nächste Universumskonstanten | Sonraki evren sabitleri
N_NEXT = Cc_b  # Channel inversion | Kanalinversion | Kanal inversiyonu
T_Om_NEXT = np.exp(-2 * PI * N_NEXT * (1 - N_NEXT))  # Conserved | Erhalten | Korunur

# =============================================================================
# KARDASHEV SCALE THRESHOLDS
# KARDASHEV-SKALA-SCHWELLENWERTE
# KARDASHEV ÖLÇEĞİ EŞİKLERİ
# =============================================================================

KD1 = N_m  # Type-1 Planetary | Typ-1 Planetar | Tip-1 Gezegen
KD2 = N_b  # Type-2 Stellar | Typ-2 Stellar | Tip-2 Yıldız
KD3 = OMEGA_LAMBDA  # Type-3 Galactic | Typ-3 Galaktisch | Tip-3 Galaksi
KD4 = 1.0 - T_Om  # Type-4 Universal | Typ-4 Universal | Tip-4 Evrensel
KD5 = 1.0  # Type-5 Omnium | Typ-5 Omnium | Tip-5 Omnium

# =============================================================================
# 4D DIRAC DERIVATION
# 4D DIRAC-ABLEITUNG
# 4D DIRAC TÜRETMESİ
# =============================================================================

DIRAC_4D_DOF = 4 * 4 + 1  # 17 degrees of freedom | Freiheitsgrade | Serbestlik derecesi
ALPHA_17 = ALPHA / DIRAC_4D_DOF  # α/17

# =============================================================================
# PLANCK UNITS
# PLANCK-EINHEITEN
# PLANCK BİRİMLERİ
# =============================================================================

L_PLANCK = np.sqrt(HBAR * G / C**3)  # Planck length | Planck-Länge | Planck uzunluğu
M_PLANCK = np.sqrt(HBAR * C / G)  # Planck mass | Planck-Masse | Planck kütlesi
T_PLANCK = np.sqrt(HBAR * G / C**5)  # Planck time | Planck-Zeit | Planck zamanı
E_PLANCK = M_PLANCK * C**2  # Planck energy | Planck-Energie | Planck enerjisi

# =============================================================================
# SOLAR SYSTEM CONSTANTS
# SONNENSYSTEMKONSTANTEN
# GÜNEŞ SİSTEMİ SABİTLERİ
# =============================================================================

M_SUN = 1.98892e30  # Solar mass | Sonnenmasse | Güneş kütlesi
R_SUN = 6.96342e8  # Solar radius | Sonnenradius | Güneş yarıçapı
M_EARTH = 5.97219e24  # Earth mass | Erdmasse | Dünya kütlesi
R_EARTH = 6.371e6  # Earth radius | Erdradius | Dünya yarıçapı

# =============================================================================
# DISPLAY FUNCTION
# ANZEIGEFUNKTION
# GÖRÜNTÜLEME FONKSİYONU
# =============================================================================

def info():
    """
    Display UST constants
    Zeige UST-Konstanten an
    UST sabitlerini göster
    """
    print("═" * 70)
    print("UST-PHYSICS v5.0 CONSTANTS")
    print("Niyazi ÖCAL | Patent: TR 2026/003258")
    print("─" * 70)
    print(f"N_b   (Blueprint)      = {N_b:.8f}")
    print(f"N_m   (Manifest)       = {N_m:.8f}")
    print(f"Cc_b  (Channel C)      = {Cc_b:.8f}")
    print(f"RA    (Transition gap) = {RA:.2e}")
    print(f"T_Om  (Tunnel)         = {T_Om:.8f}")
    print(f"κ₁    (Gear 1)         = {KAPPA1:.8f}")
    print(f"κ₂    (Gear 2)         = {KAPPA2:.8f}")
    print(f"V_b   (Gear trans)     = {V_b:.8f}")
    print("─" * 70)
    print(f"Ω_Λ   UST predicted    = {OMEGA_LAMBDA_UST:.6f}")
    print(f"Ω_Λ   Planck 2018      = {OMEGA_LAMBDA:.6f}")
    print(f"H0    ratio UST        = {H0_RATIO_UST:.6f}")
    print(f"H0    ratio observed   = {H0_LOCAL/H0_PLANCK:.6f}")
    print(f"Cycle count (1/T_Om)   = {CYCLE_COUNT:.4f}")
    print("═" * 70)

# -*- coding: utf-8 -*-
"""
UST Utility Functions
UST-Hilfsfunktionen
UST Yardımcı Fonksiyonlar

Author | Autor | Yazar: Niyazi ÖCAL
Patent: TR 2026/003258
"""

import numpy as np
from scipy import stats
from .constants import N_b, Cc_b

# =============================================================================
# UST PERCENTILE RATIO
# UST-PERZENTILVERHÄLTNIS
# UST YÜZDELİK ORANI
# =============================================================================

def ust_percentile_ratio(data, label=""):
    """
    Calculate UST percentile ratio in data
    Berechne UST-Perzentilverhältnis in Daten
    Veride UST yüzdelik oranı hesapla
    
    Computes | Berechnet | Hesaplar:
        pQ = N_b percentile of data | N_b-Perzentil der Daten | Verinin N_b yüzdeliği
        pC = Cc_b percentile of data | Cc_b-Perzentil der Daten | Verinin Cc_b yüzdeliği
        ratio = pQ/pC | Verhältnis = pQ/pC | Oran = pQ/pC
        
    Args | Argumente | Parametreler:
        data: Array of values | Wertearray | Değerler dizisi
        label: Optional label for printing | Optionales Drucketikett | Yazdırma için opsiyonel etiket
        
    Returns | Rückgabe | Döndürür:
        (pQ, pC, ratio, delta_percent) tuple
    """
    data = np.array(data)
    data = data[np.isfinite(data) & (data > 0)]
    if len(data) < 10:
        return None

    pQ = np.percentile(data, N_b * 100)
    pC = np.percentile(data, Cc_b * 100)
    ratio = pQ / pC
    theoretical = N_b / Cc_b
    delta = abs(ratio - theoretical) / theoretical * 100

    if label:
        flag = "✓✓✓" if delta < 1 else "✓✓" if delta < 5 else "✓" if delta < 15 else "—"
        print(f"{label:<40} pQ/pC={ratio:.6f}  Δ%={delta:.4f} {flag}")

    return pQ, pC, ratio, delta

# =============================================================================
# CDF NORMALIZATION
# CDF-NORMALISIERUNG
# CDF NORMALİZASYONU
# =============================================================================

def cdf_normalize(data):
    """
    CDF normalization (rank-based uniform)
    CDF-Normalisierung (rangbasiert einheitlich)
    CDF normalizasyonu (sıralama-bazlı düzgün)
    
    Args | Argumente | Parametreler:
        data: Input array | Eingabearray | Giriş dizisi
        
    Returns | Rückgabe | Döndürür:
        Normalized array [0,1] | Normalisiertes Array [0,1] | Normalize dizi [0,1]
    """
    return stats.rankdata(data) / len(data)

# =============================================================================
# GUTENBERG-RICHTER B-VALUE
# GUTENBERG-RICHTER B-WERT
# GUTENBERG-RICHTER B-DEĞERİ
# =============================================================================

def gutenberg_richter(magnitudes, min_mag=0.5, step=0.5):
    """
    Calculate Gutenberg-Richter b-value
    Berechne Gutenberg-Richter-b-Wert
    Gutenberg-Richter b-değerini hesapla
    
    Formula | Formel | Formül:
        log₁₀(N) = a - b×M
        
    Args | Argumente | Parametreler:
        magnitudes: Earthquake magnitudes | Erdbebenmagnitudes | Deprem büyüklükleri
        min_mag: Minimum magnitude | Minimale Magnitude | Minimum büyüklük
        step: Bin step size | Bin-Schrittgröße | Kutu adım boyutu
        
    Returns | Rückgabe | Döndürür:
        (b_value, r_squared) tuple
    """
    mags = np.array(magnitudes)
    bins = np.arange(min_mag, mags.max() + step, step)
    counts = np.array([np.sum(mags >= m) for m in bins])
    mask = counts > 0
    if mask.sum() < 3:
        return None, None
    slope, _, r, _, _ = stats.linregress(bins[mask], np.log10(counts[mask]))
    return -slope, r**2

# =============================================================================
# SEISMIC OMNIUM DEPTH TEST
# SEISMISCHER OMNIUM-TIEFENTEST
# SİSMİK OMNIUM DERİNLİK TESTİ
# =============================================================================

def seismic_omnium_depth(magnitudes, depths, L_formula='L4'):
    """
    T26: Seismic Omnium horizon test
    T26: Seismischer Omnium-Horizonttest
    T26: Sismik Omnium ufku testi
    
    Formula | Formel | Formül:
        L4: log₁₀(L) = 0.44×M_L - 1.3
        L1: log₁₀(L) = 0.5×M_L - 1.8
        
    Args | Argumente | Parametreler:
        magnitudes: Earthquake magnitudes | Erdbebenmagnitudes | Deprem büyüklükleri
        depths: Earthquake depths (km) | Erdbebentiefen (km) | Deprem derinlikleri (km)
        L_formula: 'L4' or 'L1' | 'L4' oder 'L1' | 'L4' veya 'L1'
        
    Returns | Rückgabe | Döndürür:
        (pQ_pC_ratio, delta_percent) from ust_percentile_ratio()
    """
    mags = np.array(magnitudes)
    depths = np.array(depths)
    mask = (mags > 0) & (depths > 0) & np.isfinite(mags) & np.isfinite(depths)
    mags, depths = mags[mask], depths[mask]

    if L_formula == 'L4':
        L = 10 ** (0.44 * mags - 1.3)
    elif L_formula == 'L1':
        L = 10 ** (0.5 * mags - 1.8)
    else:
        L = 10 ** (0.5 * mags - 1.8)

    d_over_L = depths / L
    d_over_L = d_over_L[np.isfinite(d_over_L) & (d_over_L > 0)]

    result = ust_percentile_ratio(d_over_L, "Seismic d/L (T26)")
    return result

# =============================================================================
# GENOMIC UST TEST
# GENOMISCHER UST-TEST
# GENOMİK UST TESTİ
# =============================================================================

def genomic_ust_test(heterozygosity=0.635, gc_intron=0.233,
                     rare_variant=0.640, common_variant=0.230):
    """
    T28: Genomic UST test
    T28: Genomischer UST-Test
    T28: Genomik UST testi
    
    Compares | Vergleicht | Karşılaştırır:
        - Heterozygosity with N_b | Heterozygotie mit N_b | Heterozigotluğu N_b ile
        - Homozygosity with Cc_b | Homozygotie mit Cc_b | Homozigotluğu Cc_b ile
        - GC-intron with T_Om | GC-Intron mit T_Om | GC-intron'u T_Om ile
        
    Args | Argumente | Parametreler:
        heterozygosity: Observed value | Beobachteter Wert | Gözlenen değer
        gc_intron: GC content in introns | GC-Gehalt in Intronen | İntronlarda GC içeriği
        rare_variant: Rare variant fraction | Seltene Variantenfraktion | Nadir varyant oranı
        common_variant: Common variant fraction | Häufige Variantenfraktion | Yaygın varyant oranı
        
    Returns | Rückgabe | Döndürür:
        Dictionary of delta percentages | Wörterbuch der Delta-Prozentsätze | Delta yüzdeleri sözlüğü
    """
    from .constants import N_b, Cc_b, T_Om
    return {
        'heterozygosity_delta': abs(heterozygosity - N_b) / N_b * 100,
        'homozygosity_delta': abs((1 - heterozygosity) - Cc_b) / Cc_b * 100,
        'gc_intron_delta': abs(gc_intron - T_Om) / T_Om * 100,
        'rare_variant_delta': abs(rare_variant - N_b) / N_b * 100,
        'common_variant_delta': abs(common_variant - T_Om) / T_Om * 100,
    }

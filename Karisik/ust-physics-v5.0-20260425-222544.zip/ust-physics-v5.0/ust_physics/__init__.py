# -*- coding: utf-8 -*-
"""
UST-Physics Library v5.0
Professional physics simulation package

Professionelles Physiksimulationspaket
Profesyonel fizik simülasyon paketi

Author | Autor | Yazar: Niyazi ÖCAL
Patent: TR 2026/003258
Zenodo: DOI 10.5281/zenodo.19062149

Modules:
    constants - Physical constants | Physikalische Konstanten | Fiziksel sabitler
    theorems - UST theorems T1-T28 | UST-Theoreme T1-T28 | UST teoremleri T1-T28
    utils - Helper functions | Hilfsfunktionen | Yardımcı fonksiyonlar
    gr - General Relativity | Allgemeine Relativitätstheorie | Genel Görelilik
    qft - Quantum Field Theory | Quantenfeldtheorie | Kuantum Alan Teorisi
    models - Physics models | Physikmodelle | Fizik modelleri
"""

__version__ = "5.0.0"
__author__ = "Niyazi ÖCAL"
__patent__ = "TR 2026/003258"
__zenodo__ = "DOI 10.5281/zenodo.19062149"

from . import constants
from . import theorems
from . import utils
from . import gr
from . import qft
from . import models

__all__ = ["constants", "theorems", "utils", "gr", "qft", "models"]

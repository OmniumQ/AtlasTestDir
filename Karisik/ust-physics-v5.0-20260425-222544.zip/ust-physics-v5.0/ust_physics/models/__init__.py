# -*- coding: utf-8 -*-
"""
Physics Models Module
Physikmodelle-Modul
Fizik Modelleri Modülü

Author | Autor | Yazar: Niyazi ÖCAL
"""

from .ust_model import UST17Model

__all__ = ["UST17Model"]

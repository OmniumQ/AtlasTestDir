#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
UST-Physics Library Setup
Professional GR, QFT, and UST package

Professionelles GR-, QFT- und UST-Paket
Profesyonel GR, QFT ve UST paketi

Author | Autor | Yazar: Niyazi ÖCAL
Patent: TR 2026/003258
Zenodo: DOI 10.5281/zenodo.19062149
"""

from setuptools import setup, find_packages

setup(
    name="ust-physics",
    version="5.0.0",
    author="Niyazi ÖCAL",
    author_email="niyaziocal@ust-physics.org",
    description="Professional physics library: GR, QFT, UST (Keras-style API)",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/ust-physics/ust-physics",
    packages=find_packages(exclude=["tests", "examples"]),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Science/Research",
        "Topic :: Scientific/Engineering :: Physics",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
    ],
    python_requires=">=3.8",
    install_requires=[
        "numpy>=1.21.0",
        "scipy>=1.7.0",
        "matplotlib>=3.5.0",
        "pandas>=1.3.0",
        "sympy>=1.9",
        "h5py>=3.6.0",
    ],
    extras_require={
        "quantum": ["qiskit>=0.39.0"],
        "viz": ["plotly>=5.0.0"],
    },
)

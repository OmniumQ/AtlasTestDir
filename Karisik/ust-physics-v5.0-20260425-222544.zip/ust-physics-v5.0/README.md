# 🌌 UST-Physics v5.0

**Professional Physics Library: GR + QFT + UST**

Professionelle Physikbibliothek: GR + QFT + UST

Profesyonel Fizik Kütüphanesi: GR + QFT + UST

---

## 📦 Installation | Installation | Kurulum

```bash
pip install ust-physics
```

---

## 🚀 Quick Start | Schnellstart | Hızlı Başlangıç

### UST Model

```python
import ust_physics as ust

# Display constants | Konstanten anzeigen | Sabitleri göster
ust.constants.info()

# Verify all theorems | Alle Theoreme überprüfen | Tüm teoremleri doğrula
ust.theorems.verify_all()

# Individual theorem | Einzelnes Theorem | Tekil teorem
T5_result = ust.theorems.T5_dark_energy()
print(f"Ω_Λ prediction: {T5_result[0]:.6f}")
```

### General Relativity | Allgemeine Relativitätstheorie | Genel Görelilik

```python
from ust_physics import gr

# Schwarzschild metric | Schwarzschild-Metrik | Schwarzschild metriği
metric = gr.Schwarzschild(mass=1.989e30)  # Solar mass
r_s = metric.schwarzschild_radius()
print(f"Event horizon: {r_s/1000:.2f} km")

# Geodesics | Geodäten | Jeodezikler
geodesic = gr.Geodesic(metric)
path = geodesic.integrate(initial_conditions, t_span=(0, 100))
```

### Quantum Field Theory | Quantenfeldtheorie | Kuantum Alan Teorisi

```python
from ust_physics import qft

# QED g-2 calculation | QED g-2 Berechnung | QED g-2 hesaplaması
qed = qft.QED()
g_minus_2 = qed.g2_anomaly(particle='electron')
print(f"g-2 = {g_minus_2:.10f}")

# Running coupling | Laufende Kopplung | Koşan bağlaşım
alpha_E = qft.running_alpha(energy_gev=91.2)  # Z-boson mass
```

---

## 📚 Modules | Module | Modüller

- **constants** - Physical constants | Physikalische Konstanten | Fiziksel sabitler
- **theorems** - UST theorems T1-T28 | UST Theoreme T1-T28 | UST teoremleri T1-T28
- **utils** - Helper functions | Hilfsfunktionen | Yardımcı fonksiyonlar
- **gr** - General Relativity | Allgemeine Relativitätstheorie | Genel Görelilik
- **qft** - Quantum Field Theory | Quantenfeldtheorie | Kuantum Alan Teorisi
- **models** - Pre-trained models | Vortrainierte Modelle | Ön-eğitimli modeller

---

## 📖 Documentation | Dokumentation | Dokümantasyon

Full documentation | Vollständige Dokumentation | Tam dokümantasyon:
- [English](https://ust-physics.readthedocs.io/en/)
- [Deutsch](https://ust-physics.readthedocs.io/de/)
- [Türkçe](https://ust-physics.readthedocs.io/tr/)

---

## 📄 License | Lizenz | Lisans

MIT License

Copyright (c) 2026 Niyazi ÖCAL

Patent: TR 2026/003258
Zenodo: DOI 10.5281/zenodo.19062149

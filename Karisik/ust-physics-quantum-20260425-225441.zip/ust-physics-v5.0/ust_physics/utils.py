# -*- coding: utf-8 -*-
"""
UST — Yardımcı fonksiyonlar
"""

import numpy as np
from scipy import stats
from .constants import N_b, Cc_b

def ust_percentile_ratio(data, label=""):
    """Veri dizisinde UST yüzdelik oranı hesapla"""
    data = np.array(data)
    data = data[np.isfinite(data) & (data > 0)]
    if len(data) < 10:
        return None

    pQ    = np.percentile(data, N_b * 100)
    pC    = np.percentile(data, Cc_b * 100)
    ratio = pQ / pC
    teorik = N_b / Cc_b
    delta  = abs(ratio - teorik) / teorik * 100

    if label:
        flag = "✓✓✓" if delta<1 else "✓✓" if delta<5 else "✓" if delta<15 else "—"
        print(f"{label:<40} pQ/pC={ratio:.6f}  Δ%={delta:.4f} {flag}")

    return pQ, pC, ratio, delta

def cdf_normalize(data):
    """CDF normalizasyonu"""
    return stats.rankdata(data) / len(data)

def gutenberg_richter(magnitudes, min_mag=0.5, step=0.5):
    """Gutenberg-Richter b-değeri hesapla"""
    mags = np.array(magnitudes)
    bins = np.arange(min_mag, mags.max() + step, step)
    counts = np.array([np.sum(mags >= m) for m in bins])
    mask = counts > 0
    if mask.sum() < 3:
        return None, None
    slope, _, r, _, _ = stats.linregress(bins[mask], np.log10(counts[mask]))
    return -slope, r**2

def seismic_omnium_depth(magnitudes, depths, L_formula='L4'):
    """T26: Sismik Omnium ufku testi"""
    mags   = np.array(magnitudes)
    depths = np.array(depths)
    mask   = (mags > 0) & (depths > 0) & np.isfinite(mags) & np.isfinite(depths)
    mags, depths = mags[mask], depths[mask]

    if L_formula == 'L4':
        L = 10**(0.44 * mags - 1.3)
    elif L_formula == 'L1':
        L = 10**(0.5 * mags - 1.8)
    else:
        L = 10**(0.5 * mags - 1.8)

    d_over_L = depths / L
    d_over_L = d_over_L[np.isfinite(d_over_L) & (d_over_L > 0)]

    result = ust_percentile_ratio(d_over_L, "Sismik d/L (T26)")
    return result

def genomic_ust_test(heterozygosity=0.635, gc_intron=0.233,
                     rare_variant=0.640, common_variant=0.230):
    """T28: Genomik UST testi"""
    from .constants import N_b, Cc_b, T_Om
    return {
        'heterozygosity_delta': abs(heterozygosity - N_b)/N_b*100,
        'homozygosity_delta':   abs((1-heterozygosity) - Cc_b)/Cc_b*100,
        'gc_intron_delta':      abs(gc_intron - T_Om)/T_Om*100,
        'rare_variant_delta':   abs(rare_variant - N_b)/N_b*100,
        'common_variant_delta': abs(common_variant - T_Om)/T_Om*100,
    }

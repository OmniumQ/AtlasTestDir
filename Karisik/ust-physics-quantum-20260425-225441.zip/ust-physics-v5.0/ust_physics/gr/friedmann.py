# -*- coding: utf-8 -*-
"""Friedmann Equations"""
import numpy as np
from ..constants import G, C, H0_PLANCK, OMEGA_LAMBDA, OMEGA_DM, OMEGA_B

class Friedmann:
    """Friedmann equations for cosmology"""
    
    def __init__(self, omega_lambda=OMEGA_LAMBDA, omega_dm=OMEGA_DM, omega_b=OMEGA_B):
        self.omega_lambda = omega_lambda
        self.omega_dm = omega_dm
        self.omega_b = omega_b
        self.omega_total = omega_lambda + omega_dm + omega_b
        
    def hubble_parameter(self, a):
        H0 = H0_PLANCK
        E = np.sqrt(self.omega_lambda + self.omega_dm / a**3 + self.omega_b / a**3)
        return H0 * E
    
    def critical_density(self):
        H0_si = H0_PLANCK * 1000 / (3.086e22)
        return 3 * H0_si**2 / (8 * np.pi * G)
    
    def age_of_universe(self):
        H0_si = H0_PLANCK * 1000 / (3.086e22)
        t_H = 1 / H0_si
        t_years = t_H / (365.25 * 24 * 3600)
        return t_years * 0.965

# -*- coding: utf-8 -*-
"""Schwarzschild Solution"""
import numpy as np
from ..constants import G, C

class Schwarzschild:
    """Schwarzschild metric for non-rotating black holes"""
    
    def __init__(self, mass):
        self.mass = mass
        self.r_s = 2 * G * mass / C**2
        
    def schwarzschild_radius(self):
        return self.r_s
    
    def metric_tensor(self, r, theta=np.pi/2):
        g = np.zeros((4, 4))
        g[0, 0] = -(1 - self.r_s / r)
        g[1, 1] = 1 / (1 - self.r_s / r)
        g[2, 2] = r**2
        g[3, 3] = r**2 * np.sin(theta)**2
        return g
    
    def photon_sphere(self):
        return 1.5 * self.r_s
    
    def innermost_stable_orbit(self):
        return 3 * self.r_s

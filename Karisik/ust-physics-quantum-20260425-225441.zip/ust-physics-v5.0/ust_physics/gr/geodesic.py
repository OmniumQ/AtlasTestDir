# -*- coding: utf-8 -*-
"""Geodesic Calculator"""
import numpy as np
from scipy.integrate import solve_ivp

class Geodesic:
    """Geodesic equation solver"""
    
    def __init__(self, metric):
        self.metric = metric
        
    def christoffel_symbols(self, r):
        rs = self.metric.r_s
        gamma = {}
        gamma['t_tr'] = rs / (2 * r * (r - rs))
        gamma['r_tt'] = rs * (r - rs) / (2 * r**3)
        gamma['r_rr'] = -rs / (2 * r * (r - rs))
        gamma['r_theta_theta'] = -(r - rs)
        gamma['r_phi_phi'] = -(r - rs) * np.sin(np.pi/2)**2
        gamma['theta_r_theta'] = 1 / r
        gamma['phi_r_phi'] = 1 / r
        return gamma
    
    def integrate(self, initial_conditions, t_span, n_points=1000):
        def geodesic_equations(lam, y):
            t, r, theta, phi, dt, dr, dtheta, dphi = y
            gamma = self.christoffel_symbols(r)
            ddt = -2 * gamma['t_tr'] * dt * dr
            ddr = gamma['r_tt'] * dt**2 + gamma['r_rr'] * dr**2
            ddtheta = -2 * gamma['theta_r_theta'] * dr * dtheta
            ddphi = -2 * gamma['phi_r_phi'] * dr * dphi
            return [dt, dr, dtheta, dphi, ddt, ddr, ddtheta, ddphi]
        
        sol = solve_ivp(geodesic_equations, t_span, initial_conditions,
                       dense_output=True, max_step=0.1)
        return sol

import numpy as np
from ..constants import ALPHA, PI, M_E, C, HBAR, H_PLANCK

class QED:
    def __init__(self):
        self.alpha = ALPHA
    def g2_anomaly(self, particle='electron', order=1):
        a_1 = self.alpha / (2 * PI)
        if order == 1: return a_1
        a_2 = 0.328478965 * (self.alpha / PI)**2
        if order == 2: return a_1 + a_2
        a_3 = 1.181234 * (self.alpha / PI)**3
        return a_1 + a_2 + a_3
    def compton_wavelength(self):
        return H_PLANCK / (M_E * C)

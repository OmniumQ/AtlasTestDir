import numpy as np
from ..constants import ALPHA, ALPHA_S, PI

def running_alpha(energy_gev, n_flavors=1):
    m_e_gev = 0.511e-3
    if energy_gev <= m_e_gev: return ALPHA
    beta0 = (4/3) * n_flavors
    t = np.log(energy_gev / m_e_gev)
    return ALPHA / (1 - (ALPHA / (3 * PI)) * beta0 * t)

def running_alpha_s(energy_gev, n_flavors=5):
    M_Z = 91.2
    if energy_gev <= 1.0: return ALPHA_S
    beta0 = 11 - (2 * n_flavors / 3)
    t = np.log(energy_gev / M_Z)
    return ALPHA_S / (1 + beta0 * ALPHA_S * t / (2 * PI))

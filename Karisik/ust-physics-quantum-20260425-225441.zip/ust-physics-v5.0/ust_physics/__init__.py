# -*- coding: utf-8 -*-
"""
UST-Physics Library v5.0
Professional physics simulation package with Quantum Gravity

Author: Niyazi ÖCAL
Patent: TR 2026/003258
"""

__version__ = "5.0.0"
__author__ = "Niyazi ÖCAL"
__patent__ = "TR 2026/003258"
__zenodo__ = "DOI 10.5281/zenodo.19062149"

from . import constants
from . import theorems
from . import utils
from . import gr
from . import qft
from . import models
from . import quantum_gravity

__all__ = ["constants", "theorems", "utils", "gr", "qft", "models", "quantum_gravity"]

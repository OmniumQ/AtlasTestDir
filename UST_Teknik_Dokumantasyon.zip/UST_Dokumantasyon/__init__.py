"""
UST — Unified Source Theory
Niyazi ÖCAL, 2026
Patent: TR 2026/003258
Zenodo: DOI 10.5281/zenodo.19062149

Kullanım:
    import ust
    ust.info()
    ust.verify_all()
    ust.T11_hadronic()
"""

from .constants import (
    N_b, N_m, Cc_b, Cc_m, RA,
    T_Om, BPL, KAPPA1, KAPPA2, V_b,
    G_TT, G_RR, PHI, PI, ALPHA,
    OMEGA_LAMBDA, OMEGA_DM, OMEGA_B,
    LAMBDA_UST, H0_RATIO_UST,
    CYCLE_COUNT, N_NEXT, T_Om_NEXT,
    KD1, KD2, KD3, KD4, KD5,
    info
)

from .theorems import (
    T1_stabilization_rate,
    T2_fidelity_bound,
    T3_entropy, T3_eigenvalues,
    T4_su3_link,
    T5_dark_energy,
    T10_tunnel,
    T11_hadronic,
    T12_cmb_temperature,
    T13_cmb_polarisation,
    T14_polarisation_angle,
    T15_tunnel_identity,
    T16_dark_matter_half,
    T17_black_hole,
    T18_T22_kardashev,
    T23_hubble_tension,
    T24_neutron_star,
    T25_cyclic_universe,
    T26_seismic,
    T27_seismic_frequency,
    T28_genomic,
    verify_all,
)

from .utils import (
    ust_percentile_ratio,
    cdf_normalize,
    gutenberg_richter,
    seismic_omnium_depth,
    genomic_ust_test,
)

__version__ = "5.0.0"
__author__  = "Niyazi ÖCAL"
__patent__  = "TR 2026/003258"
__zenodo__  = "DOI 10.5281/zenodo.19062149"

"""
UST — Unified Source Theory
Evrensel sabitler modülü
Niyazi ÖCAL, 2026
Patent: TR 2026/003258
"""

import numpy as np

# ── Temel fizik sabitleri ────────────────────────────────────────
PI    = np.pi
PHI   = (1 + np.sqrt(5)) / 2        # Altın oran
ALPHA = 7.2973525693e-3              # İnce yapı sabiti
C     = 2.99792458e8                 # Işık hızı (m/s)
G     = 6.67430e-11                  # Gravitasyon sabiti
HBAR  = 1.054571817e-34              # Indirgenmiş Planck sabiti
K_B   = 1.380649e-23                 # Boltzmann sabiti
H0_PLANCK = 67.4                     # Planck H0 (km/s/Mpc)
H0_LOCAL  = 73.0                     # Lokal H0 (km/s/Mpc)

# ── UST Blueprint-Manifest sabitleri ────────────────────────────
N_GEO = (3 - np.sqrt(3)) / 2        # Geometrik kök = 0.63397460
N_b   = N_GEO - ALPHA / 17          # Blueprint = 0.63354460
N_m   = 0.63353522                   # Manifest (ampirik)
Cc_b  = 1.0 - N_b                   # Channel C = 0.36645540
Cc_m  = 1.0 - N_m                   # Channel C manifest
RA    = N_b - N_m                    # Geçiş boşluğu = 9.38e-6

# ── Omnium tünel sabiti ──────────────────────────────────────────
T_Om  = np.exp(-2 * PI * N_b * Cc_b)   # = 0.23252885
BPL   = N_b * N_m                       # Blueprint-Manifest çarpımı

# ── Gear (Vites) sabitleri ───────────────────────────────────────
KAPPA1 = PI * N_b                    # Gear 1 = 1.990339
KAPPA2 = 2 * PI * N_b               # Gear 2 = 3.980678
V_b    = (1 + N_b) / (2 - N_b)     # Gear geçiş fonksiyonu = 1.195461

# ── Metrik bileşenleri ───────────────────────────────────────────
G_TT = -(1 - N_b) * (2 - N_b)      # = -0.500745
G_RR = 1.0 / ((1 - N_b) * (2 - N_b))  # = 1.997025

# ── Kozmolojik değerler (Planck 2018) ───────────────────────────
OMEGA_LAMBDA = 0.6857               # Karanlık enerji
OMEGA_DM     = 0.2717               # Karanlık madde
OMEGA_B      = 0.0486               # Baryonik madde
LAMBDA_OBS   = 1.100e-52            # Kozmolojik sabit (m^-2)
LAMBDA_PLANCK = 1.0 / (1.616e-35)**2  # Planck Lambdası

# ── UST türetilen kozmolojik değerler ────────────────────────────
OMEGA_LAMBDA_UST = N_b + OMEGA_DM / (PHI * PI)
LAMBDA_UST = LAMBDA_PLANCK * (N_b**2)**(2/(1+ALPHA))
H0_RATIO_UST = 1 + N_b * Cc_b**2   # = 1.085078

# ── 4D Dirac türetmesi ───────────────────────────────────────────
DIRAC_4D_DOF = 4*4 + 1              # = 17 (serbestlik derecesi)
ALPHA_17     = ALPHA / DIRAC_4D_DOF # = 0.00042926

# ── Döngüsel evren ───────────────────────────────────────────────
CYCLE_COUNT  = 1.0 / T_Om           # = 4.3005
N_NEXT       = Cc_b                  # Sonraki evren sabiti
T_Om_NEXT    = np.exp(-2*PI*N_NEXT*(1-N_NEXT))  # = T_Om (korunur)

# ── Kardashev eşikleri ───────────────────────────────────────────
KD1 = N_m                            # Tip-1 Gezegen
KD2 = N_b                            # Tip-2 Yıldız
KD3 = OMEGA_LAMBDA                   # Tip-3 Galaksi
KD4 = 1.0 - T_Om                    # Tip-4 Evren
KD5 = 1.0                            # Tip-5 Omnium

def info():
    """UST sabitlerini ekrana yazdır"""
    print(f"{'═'*55}")
    print(f"UST v5 — Unified Source Theory")
    print(f"Niyazi ÖCAL | Patent: TR 2026/003258")
    print(f"{'─'*55}")
    print(f"N_b   (Blueprint)  = {N_b:.8f}")
    print(f"N_m   (Manifest)   = {N_m:.8f}")
    print(f"Cc_b  (Channel C)  = {Cc_b:.8f}")
    print(f"RA    (Geçiş)      = {RA:.2e}")
    print(f"T_Om  (Tünel)      = {T_Om:.8f}")
    print(f"κ₁    (Gear 1)     = {KAPPA1:.8f}")
    print(f"κ₂    (Gear 2)     = {KAPPA2:.8f}")
    print(f"V_b   (Gear geçiş) = {V_b:.8f}")
    print(f"Döngü sayısı 1/T   = {CYCLE_COUNT:.4f}")
    print(f"{'─'*55}")
    print(f"Ω_Λ UST türetilen  = {OMEGA_LAMBDA_UST:.6f}")
    print(f"Ω_Λ Planck 2018    = {OMEGA_LAMBDA:.6f}")
    print(f"H0 oranı UST       = {H0_RATIO_UST:.6f}")
    print(f"H0 oranı gözlem    = {H0_LOCAL/H0_PLANCK:.6f}")
    print(f"{'═'*55}")
